const int potPin = A0;
const int ledPin = 13;  // Assuming the onboard LED is connected to pin 13

void setup() {
  Serial.begin(9600);
  pinMode(ledPin, OUTPUT);
}

void loop() {
  int sensorValue = analogRead(potPin);

  // Send the sensor value to the Serial Plotter
  Serial.println(sensorValue);

  // If the sensor value is greater than 800, turn on the onboard LED
  if (sensorValue > 800) {
    digitalWrite(ledPin, HIGH);
  } else {
    digitalWrite(ledPin, LOW);
  }

  // Print the sensor value in CSV format to Serial
  Serial.print(sensorValue);
  Serial.print(",");

  delay(100);  // Adjust the delay as needed
}

