from machine import Pin
import time

# -----------------------------
# Pin Configuration
# -----------------------------

# Pushbuttons (External 10K pull-down resistors)
button_forward = Pin(4, Pin.IN)   # GPIO4
button_reverse = Pin(5, Pin.IN)   # GPIO5

# L298N Motor Driver Inputs
in1 = Pin(19, Pin.OUT)  # GPIO19
in2 = Pin(18, Pin.OUT)  # GPIO18


# -----------------------------
# Motor Control Functions
# -----------------------------

def motor_forward():
    in1.value(1)
    in2.value(0)
    print("Motor Running FORWARD")

def motor_reverse():
    in1.value(0)
    in2.value(1)
    print("Motor Running REVERSE")

def motor_stop():
    in1.value(0)
    in2.value(0)
    print("Motor STOPPED")


# -----------------------------
# Main Loop
# -----------------------------

while True:
    
    forward_state = button_forward.value()
    reverse_state = button_reverse.value()
    
    if forward_state == 1 and reverse_state == 0:
        motor_forward()
        
    elif reverse_state == 1 and forward_state == 0:
        motor_reverse()
        
    elif forward_state == 0 and reverse_state == 0:
        motor_stop()
        
    else:
        # Safety case: both buttons pressed
        motor_stop()
        print("Both buttons pressed - Motor STOPPED (Safety)")
    
    time.sleep(0.1)  # Debounce delay

