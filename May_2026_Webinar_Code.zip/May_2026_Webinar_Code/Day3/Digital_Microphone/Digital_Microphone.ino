#include <PDM.h>
short sampleBuffer[256];
// number of samples read
volatile int samplesRead;

void setup() {
  Serial.begin(9600);
  //PDM.setGain(200);
  while (!Serial);
  // configure the data receive callback
  PDM.onReceive(onPDMdata);
  // one channel (mono mode) 16 kHz sample rate
  if (!PDM.begin(1, 16000)) {
    Serial.println("Failed to start PDM!");
    while (1);
  }
}

void loop() {
  if (samplesRead) {
    for (int i = 0; i < samplesRead; i++) {
      Serial.println(sampleBuffer[i]);
      delay(50);
    }
    // clear the read count
    samplesRead = 0;
  }
}

void onPDMdata() {
  // query the number of bytes available
  int bytesAvailable = PDM.available();
  // read into the sample buffer
  PDM.read(sampleBuffer, bytesAvailable);
  // 16-bit, 2 bytes per sample
  samplesRead = bytesAvailable / 2;
}







