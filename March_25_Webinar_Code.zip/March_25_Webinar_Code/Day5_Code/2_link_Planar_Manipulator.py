import numpy as np
import matplotlib.pyplot as plt

def forward_kinematics(theta1, theta2, L1, L2):
    """Computes the end effector position for a 2-link planar robot arm"""
    x1 = L1 * np.cos(theta1)
    y1 = L1 * np.sin(theta1)
    
    x2 = x1 + L2 * np.cos(theta1 + theta2)
    y2 = y1 + L2 * np.sin(theta1 + theta2)

    return [(0, 0), (x1, y1), (x2, y2)]

# Robot arm parameters
L1, L2 = 2, 1.5  # Link lengths
theta1, theta2 = np.radians(90), np.radians(45)  # Joint angles

# Compute positions
positions = forward_kinematics(theta1, theta2, L1, L2)

# Plot the robot arm
x_vals, y_vals = zip(*positions)
plt.figure(figsize=(5, 5))
plt.plot(x_vals, y_vals, marker='o', linestyle='-', color='b', markersize=10)
plt.xlim(-4, 4)
plt.ylim(-4, 4)
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.title("2-Link Planar Robot Arm")
plt.grid()
plt.show()
