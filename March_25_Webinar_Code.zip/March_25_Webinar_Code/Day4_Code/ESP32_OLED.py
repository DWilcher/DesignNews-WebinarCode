from machine import Pin, I2C
import ssd1306
import time

# Configuration
WIDTH = 128
HEIGHT = 64
I2C_ADDR = 0x3C  # Default address of SSD1306

# Initialize I2C
i2c = I2C(0, scl=Pin(22), sda=Pin(21), freq=400000) # Adjust pins as needed for your board

# Initialize OLED display
display = ssd1306.SSD1306_I2C(WIDTH, HEIGHT, i2c, I2C_ADDR)

def setup():
    print("Initializing...")
    try:
        display.fill(0)  # Clear the display
        display.text("HELLO WORLD!", 0, 30, 1) # draw text with white color (1)
        display.show()
        time.sleep(2)  # Delay for 2 seconds
    except OSError as e:
        print(f"SSD1306 allocation failed: {e}")
        while True:
            pass #infinite loop to stop the program.

def loop():
    display.scroll(1, 0) # scroll right
    display.show()
    time.sleep(7)
    display.scroll(0, 0) # stop scroll
    display.show()
    time.sleep(1)
    display.scroll(-1, 0) # scroll left
    display.show()
    time.sleep(7)
    display.scroll(0, 0) # stop scroll
    display.show()
    time.sleep(1)

# Main execution
setup()
while True:
    loop() #Write your code here :-)h
