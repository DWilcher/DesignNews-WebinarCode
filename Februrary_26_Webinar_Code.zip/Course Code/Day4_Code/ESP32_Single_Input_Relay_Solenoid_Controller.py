from machine import Pin
import time

# -----------------------------
# Pin Configuration
# -----------------------------

# Pushbutton (External 10K pull-down resistor)
button = Pin(4, Pin.IN)        # GPIO4 input

# Relay Control Output
relay = Pin(5, Pin.OUT)        # GPIO5 output


# -----------------------------
# Relay Control Functions
# -----------------------------

def relay_on():
    relay.value(1)
    print("Relay ON - Solenoid Energized")

def relay_off():
    relay.value(0)
    print("Relay OFF - Solenoid De-energized")


# -----------------------------
# Main Loop
# -----------------------------

while True:
    
    button_state = button.value()
    
    if button_state == 1:
        relay_on()
    else:
        relay_off()
    
    time.sleep(0.05)   # Small debounce delay
