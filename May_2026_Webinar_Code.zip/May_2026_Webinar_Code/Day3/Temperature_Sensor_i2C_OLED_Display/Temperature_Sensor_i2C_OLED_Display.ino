#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Arduino_HTS221.h>

//Adafruit_SSD1306 display(128, 64);

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

#define OLED_RESET  4
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

const int potPin = A0; // Define the analog pin connected to the potentiometer

void setup() {
    Serial.begin(9600);
    display.setTextColor(SSD1306_WHITE);// Set the color for the text

  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("SSD1306 allocation failed"));
    for(;;);
  }

  
  // Set the background color to black
  display.fillRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, SSD1306_BLACK);
  display.display();
  delay(2000);
  display.clearDisplay();  // Clear the display after setting the background color
}
  

void loop() {
  float temperature = HTS.readTemperature();
  
  // Display the potentiometer value and percentage on the OLED display
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.print("Temp");
  display.setTextSize(2);
  display.setCursor(0,12);
  String temp = String(temperature);
  temp = temp + "*C";
  display.print(temp);
  Serial.println(temp);
  delay(100);
}
 
 

