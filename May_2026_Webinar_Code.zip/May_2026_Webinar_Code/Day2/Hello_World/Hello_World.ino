#include <Adafruit_GFX.h>
#include <Wire.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

#define OLED_RESET -1 // Reset pin # (or -1 if sharing Arduino reset pin)

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

void setup() {
  // Initialize the OLED display
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);

  // Clear the display
  display.clearDisplay();

  // Set the display brightness
  //display.setBrightness(255);

  // Set the text color to white
  display.setTextColor(WHITE);

  // Set text size
  display.setTextSize(2);

  // Set the cursor position
  display.setCursor(0, 0);

  // Display the message "Hello, world!"
  display.println("Hello,world!");

  // Update the display
  display.display();
}

void loop() {
  // Nothing to do in the loop function
}

