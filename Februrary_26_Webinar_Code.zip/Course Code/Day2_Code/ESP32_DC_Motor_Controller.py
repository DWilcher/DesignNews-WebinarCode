from machine import Pin
import time

# Pushbutton input (external 10k pulldown resistor)
button = Pin(4, Pin.IN)

# Motor driver output
motor_driver = Pin(5, Pin.OUT)

# Debounce time (milliseconds)
DEBOUNCE_TIME = 0.02  # 20 ms

last_button_state = button.value()

while True:
    current_state = button.value()

    # Debounce logic
    if current_state != last_button_state:
        time.sleep(DEBOUNCE_TIME)
        current_state = button.value()

    # Button pressed (HIGH) → Motor ON
    if current_state == 1:
        motor_driver.on()
    else:
        motor_driver.off()

    last_button_state = current_state
    time.sleep(0.01)
