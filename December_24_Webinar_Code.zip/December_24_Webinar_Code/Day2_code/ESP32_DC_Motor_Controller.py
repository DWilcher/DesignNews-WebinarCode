#ESP32_DC Motor_Controller

from machine import Pin
import time

# Define GPIO pins
button_pin = Pin(18, Pin.IN)  # Pushbutton with pull-up resistor
led_pin = Pin(2, Pin.OUT)  # LED pin
motor_pin = Pin(4, Pin.OUT)  # Motor pin

# Initialize variables
previous_state = button_pin.value()

# Main loop
try:
    while True:
        # Read the current state of the button
        button_state = button_pin.value()

        # Detect a press event
        if button_state == 1 and previous_state == 0:  # Button pressed
            led_pin.value(1)  # Turn on LED
            motor_pin.value(1) # Turn on Motor

        # Detect a release event
        if button_state == 0 and previous_state == 1:  # Button released
            led_pin.value(0)  # Turn off LED
            motor_pin.value(0) # Turn on Motor

        # Update the previous state
        previous_state = button_state

        time.sleep(0.05)  # Debounce delay
except KeyboardInterrupt:
    print("Program terminated.")
