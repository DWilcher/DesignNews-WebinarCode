import pandas as pd
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Input
from tensorflow.keras.utils import to_categorical
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split

# ------------------------------------------------------------
# Load the CSV file containing the classified fruit data
# ------------------------------------------------------------
csv_file = "fruit_classified_output.csv"   # <-- Load the output from the previous classification step
df = pd.read_csv(csv_file)

print("Loaded Data:")
print(df.head())

# ------------------------------------------------------------
# Prepare features (RGB) and labels (Fruit)
# ------------------------------------------------------------
X = df[["Red", "Green", "Blue"]].values  # features

# Encode fruit labels to integers
label_encoder = LabelEncoder()
y_int = label_encoder.fit_transform(df["Fruit"].values)
y = to_categorical(y_int)  # one-hot encoding for Keras

# Split data into training and test sets (optional but recommended)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# ------------------------------------------------------------
# Build the neural network
# ------------------------------------------------------------
model = Sequential([
    Input(shape=(3,)), # Explicitly define the input layer
    Dense(16, activation='relu'),
    Dense(16, activation='relu'),
    Dense(y.shape[1], activation='softmax')  # output layer: number of fruit classes
])

# Compile the model
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# ------------------------------------------------------------
# Train the model
# ------------------------------------------------------------
model.fit(X_train, y_train, epochs=100, batch_size=8, verbose=1)

# Evaluate the model
loss, accuracy = model.evaluate(X_test, y_test, verbose=0)
print(f"\nTest Accuracy: {accuracy*100:.2f}%")

# ------------------------------------------------------------
# Predict fruit for all samples
# ------------------------------------------------------------
predictions = model.predict(X)
predicted_labels = label_encoder.inverse_transform(np.argmax(predictions, axis=1))

df["Predicted_Fruit"] = predicted_labels

# ------------------------------------------------------------
# Print results
# ------------------------------------------------------------
print("\n=== Classification Results ===")
print(df)

# ------------------------------------------------------------
# Save output for further processing
# ------------------------------------------------------------
output_file = "fruit_classified_keras_output.csv"
df.to_csv(output_file, index=False)
print("\nSaved:", output_file)
