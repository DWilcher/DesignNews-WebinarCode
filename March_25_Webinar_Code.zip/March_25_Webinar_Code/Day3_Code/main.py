from machine import Pin, PWM, ADC
from time import sleep

servoPin = 26  # GPIO pin used to connect the servo control
potPin = 15    # GPIO pin used to connect the potentiometer wiper

# Create a PWM object on the servo pin
servo = PWM(Pin(servoPin), freq=50)

# Create an ADC object for the potentiometer
pot = ADC(Pin(potPin))
pot.atten(ADC.ATTN_11DB)  # Set attenuation to read full 0-3.3V range

def set_angle(angle):
    # Convert angle (0 to 180) to duty cycle (adjust for your servo)
    duty = int((angle / 180) * (125 - 25) + 25)  # Map angle to duty cycle range
    servo.duty(duty)

while True:
    pot_value = pot.read()  # Read potentiometer value (0 to 4095)
    angle = (pot_value / 4095) * 180  # Map potentiometer value to servo angle
    set_angle(angle)
    sleep(0.1)  # Small delay for stability# Write your code here :-)
