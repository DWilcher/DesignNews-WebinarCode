from machine import Pin
import time

# Define GPIO pins
button_pin = Pin(18, Pin.IN)  # Pushbutton with pull-up resistor
led_pin = Pin(2, Pin.OUT)  # LED pin

# Initialize variables
previous_state = button_pin.value()

# Main loop
try:
    while True:
        # Read the current state of the button
        button_state = button_pin.value()

        # Detect state change
        if button_state != previous_state:
            if button_state == 1:  # Button pressed (active high)
                print("Switch-Pressed (Binary 1)")
                print(button_state)
                led_pin.value(1)  # Turn on LED

            else:  # Button released
                print("Switch-Released (Binary 0)")
                led_pin.value(0)  # Turn off LED

            previous_state = button_state  # Update previous state

        time.sleep(0.1)  # Debounce delay
except KeyboardInterrupt:
    print("Program terminated.")

