import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def rotation_matrix(axis, theta):
    """Returns a rotation matrix for a given axis and angle (radians)."""
    if axis == 'x':
        return np.array([[1, 0, 0], 
                         [0, np.cos(theta), -np.sin(theta)], 
                         [0, np.sin(theta), np.cos(theta)]])
    elif axis == 'y':
        return np.array([[np.cos(theta), 0, np.sin(theta)], 
                         [0, 1, 0], 
                         [-np.sin(theta), 0, np.cos(theta)]])
    elif axis == 'z':
        return np.array([[np.cos(theta), -np.sin(theta), 0], 
                         [np.sin(theta), np.cos(theta), 0], 
                         [0, 0, 1]])

def homogeneous_transform(R, t):
    """Returns a 4x4 homogeneous transformation matrix."""
    T = np.eye(4)
    T[:3, :3] = R
    T[:3, 3] = t
    return T

# Define link lengths
L1 = 2
L2 = 1.5

# Define joint angles (in radians)
theta1 = np.pi / 6  # 30 degrees rotation about Z
theta2 = np.pi / 4  # 45 degrees rotation about Y

# Define translation vectors
t1 = np.array([0, 0, L1])  # First joint translation
t2 = np.array([L2, 0, 0])  # Second joint translation

# Compute transformation matrices
R1 = rotation_matrix('z', theta1)
R2 = rotation_matrix('y', theta2)

T1 = homogeneous_transform(R1, t1)
T2 = homogeneous_transform(R2, t2)

# Compute final end effector position
P0 = np.array([0, 0, 0, 1])  # Base position
P1 = T1 @ P0  # First joint position
P2 = T1 @ T2 @ P0  # End effector position

# Extract coordinates
x_vals = [P0[0], P1[0], P2[0]]
y_vals = [P0[1], P1[1], P2[1]]
z_vals = [P0[2], P1[2], P2[2]]

# Plot the robot arm
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.plot(x_vals, y_vals, z_vals, marker='o', linestyle='-', color='b', label="Robot Arm")
ax.scatter(x_vals, y_vals, z_vals, color='r', s=50)  # Mark joint positions
ax.set_xlabel("X-axis")
ax.set_ylabel("Y-axis")
ax.set_zlabel("Z-axis")
ax.set_title("3D Robot Arm Simulation")
ax.legend()
plt.show()
