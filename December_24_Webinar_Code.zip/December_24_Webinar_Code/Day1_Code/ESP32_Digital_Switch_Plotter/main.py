#ESP32_Digital_Switch_Plotter

from machine import Pin
import time

# Define GPIO pins
button_pin = Pin(18, Pin.IN)  # Pushbutton
led_pin = Pin(2, Pin.OUT)  # LED pin

# Initialize variables
previous_state = button_pin.value()

# Main loop
try:
    while True:
        # Read the current state of the button
        button_state = button_pin.value()

        # Detect a press event
        if button_state == 1 and previous_state == 0:  # Button pressed
         print("Switch Button press")
         for i in range(1,5):
            print((button_state, button_state, button_state))  # Send pulse start to Mu Plotter
            led_pin.value(1)  # Turn on LED
            time.sleep(0.1)  # Short delay to simulate pulse width

        # Detect a release event
        if button_state == 0 and previous_state == 1:  # Button released
         print("Switch Button released")
         for i in range(1,5):
            print((button_state, button_state, button_state))# Send pulse end to Mu Plotter
            led_pin.value(0)  # Turn off LED
            time.sleep(0.1)  # Short delay to simulate pulse width

        # Update the previous state
        previous_state = button_state

        time.sleep(0.05)  # Debounce delay
except KeyboardInterrupt:
    print("Program terminated.")

