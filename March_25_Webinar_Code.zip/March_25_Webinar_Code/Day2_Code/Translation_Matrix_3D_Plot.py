import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def transform_point(T, P):
    """Apply a transformation matrix T to a point P using the dot product.
    Ensure that decimal values in T do not affect the Z transformation unexpectedly."""
    P_transformed = np.dot(T, P)

    # Explicitly ensure Z value is computed as expected
    P_transformed[2] = np.round(P_transformed[2], 6)  # Rounding to mitigate floating point errors

    return P_transformed

# User input for the point
x = float(input("Enter x coordinate of the point: "))
y = float(input("Enter y coordinate of the point: "))
z = float(input("Enter z coordinate of the point: "))
w = float(input("Enter w coordinate of the point: "))  # Homogeneous coordinate
P = np.array([[x], [y], [z], [w]])  # (x, y, z, w)

# User input for the 4x4 transformation matrix
print("Enter the 4x4 transformation matrix row by row (decimal values allowed but should not affect Z result):")
T = np.array([[float(input(f"Row {i+1}, Col {j+1}: ")) for j in range(4)] for i in range(4)])

# Apply the transformation
P_transformed = transform_point(T, P)

# Extract coordinates for plotting (ignoring the w coordinate since it's not part of 3D space)
x_vals = [P[0,0], P_transformed[0,0]]
y_vals = [P[1,0], P_transformed[1,0]]
z_vals = [P[2,0], P_transformed[2,0]]

# Create a 3D plot
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Plot original and transformed points with larger dots
ax.scatter(x_vals[0], y_vals[0], z_vals[0], color='r', s=100, label='Original Point')
ax.scatter(x_vals[1], y_vals[1], z_vals[1], color='b', s=100, label='Transformed Point')

# Draw a line connecting the points
ax.plot(x_vals, y_vals, z_vals, 'k--')

# Display coordinates as text near the points
ax.text(x_vals[0], y_vals[0], z_vals[0], f'({x_vals[0]}, {y_vals[0]}, {z_vals[0]})', color='red')
ax.text(x_vals[1], y_vals[1], z_vals[1], f'({x_vals[1]}, {y_vals[1]}, {z_vals[1]})', color='blue')

# Labels and title
ax.set_xlabel('X Axis')
ax.set_ylabel('Y Axis')
ax.set_zlabel('Z Axis')
ax.set_title('3D Plot of Original and Transformed Points')
ax.legend()

# Show the plot
plt.show()

# Display results
print("Original Point:\n", P)
print("Transformation Matrix:\n", T)
print("Transformed Point:\n", P_transformed)
