"""
Morse Code Flasher (MicroPython)
- Type a word into the Thonny Shell
- Press Enter
- LED on GPIO2 flashes Morse code
- Dots and dashes printed in real time
"""

from machine import Pin
import time
import sys

# LED setup
led = Pin(2, Pin.OUT)
led.off()

# Morse timing (milliseconds)
UNIT = 200  # adjust speed here

# Morse code dictionary
MORSE_TABLE = {
    'A': '.-',    'B': '-...',  'C': '-.-.',  'D': '-..',   'E': '.',
    'F': '..-.',  'G': '--.',   'H': '....',  'I': '..',    'J': '.---',
    'K': '-.-',   'L': '.-..',  'M': '--',    'N': '-.',    'O': '---',
    'P': '.--.',  'Q': '--.-',  'R': '.-.',   'S': '...',   'T': '-',
    'U': '..-',   'V': '...-',  'W': '.--',   'X': '-..-', 'Y': '-.--',
    'Z': '--..',
    '0': '-----', '1': '.----', '2': '..---', '3': '...--',
    '4': '....-', '5': '.....', '6': '-....', '7': '--...',
    '8': '---..', '9': '----.',
    ' ': ' '
}

# ---- Morse helpers ----

def flash_dot():
    sys.stdout.write('.')
    led.on()
    time.sleep_ms(UNIT)
    led.off()

def flash_dash():
    sys.stdout.write('-')
    led.on()
    time.sleep_ms(UNIT * 3)
    led.off()

def play_morse(character):
    code = MORSE_TABLE.get(character)
    if code is None:
        return

    # Word gap
    if character == ' ':
        sys.stdout.write(' / ')
        time.sleep_ms(UNIT * 7)
        return

    sys.stdout.write(character + ': ')

    for symbol in code:
        if symbol == '.':
            flash_dot()
        elif symbol == '-':
            flash_dash()

        # Space between symbols
        time.sleep_ms(UNIT)
        sys.stdout.write(' ')

    # Space between letters
    sys.stdout.write('   ')
    time.sleep_ms(UNIT * 3)

# ---- Main loop ----

print("Type a word and press Enter:")

while True:
    try:
        text = sys.stdin.readline().strip()

        if not text:
            continue

        text = text.upper()
        print("\nFlashing Morse for:", text)

        for char in text:
            play_morse(char)

        print("\n\nDone.\nType another word:")

    except KeyboardInterrupt:
        led.off()
        print("\nStopped.")
        break