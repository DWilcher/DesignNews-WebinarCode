"""
Morse Code Flasher (MicroPython)
- Type a word into the serial REPL
- Press Enter
- LED on GPIO2 flashes Morse code
"""

from machine import Pin
import time
import sys

# LED setup
led = Pin(2, Pin.OUT)
led.off()

# Morse timing (milliseconds)
UNIT = 200  # adjust speed here

# Morse code dictionary
MORSE_TABLE = {
    'A': '.-',    'B': '-...',  'C': '-.-.',  'D': '-..',   'E': '.',
    'F': '..-.',  'G': '--.',   'H': '....',  'I': '..',    'J': '.---',
    'K': '-.-',   'L': '.-..',  'M': '--',    'N': '-.',    'O': '---',
    'P': '.--.',  'Q': '--.-',  'R': '.-.',   'S': '...',   'T': '-',
    'U': '..-',   'V': '...-',  'W': '.--',   'X': '-..-', 'Y': '-.--',
    'Z': '--..',
    '0': '-----', '1': '.----', '2': '..---', '3': '...--',
    '4': '....-', '5': '.....', '6': '-....', '7': '--...',
    '8': '---..', '9': '----.',
    ' ': ' '      # space between words
}

# ---- Morse helpers ----

def flash_dot():
    led.on()
    time.sleep_ms(UNIT)
    led.off()

def flash_dash():
    led.on()
    time.sleep_ms(UNIT * 3)
    led.off()

def play_morse(character):
    code = MORSE_TABLE.get(character)
    if code is None:
        return

    # Word gap
    if character == ' ':
        time.sleep_ms(UNIT * 7)
        return

    for symbol in code:
        if symbol == '.':
            flash_dot()
        elif symbol == '-':
            flash_dash()

        # Space between symbols
        time.sleep_ms(UNIT)

    # Space between letters
    time.sleep_ms(UNIT * 3)

# ---- Main loop ----

print("Type a word and press Enter:")

while True:
    try:
        # Read line from serial
        text = sys.stdin.readline().strip()

        if not text:
            continue

        text = text.upper()
        print("Flashing Morse for:", text)

        for char in text:
            play_morse(char)

        print("Done.\nType another word:")

    except KeyboardInterrupt:
        led.off()
        print("\nStopped.")
        break

