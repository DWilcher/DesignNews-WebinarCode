from machine import Pin, I2C, ADC, PWM
import ssd1306
import time

# Configuration
WIDTH = 128
HEIGHT = 64
I2C_ADDR = 0x3C  # Default address of SSD1306
POT_PIN = 15
SERVO_PIN = 26

# Initialize I2C
i2c = I2C(0, scl=Pin(22), sda=Pin(21), freq=400000)

# Initialize OLED display
display = ssd1306.SSD1306_I2C(WIDTH, HEIGHT, i2c, I2C_ADDR)

# Initialize Potentiometer and Servo
pot = ADC(Pin(POT_PIN))
pot.atten(ADC.ATTN_11DB)  # Full range: 0-3.3V
servo = PWM(Pin(SERVO_PIN))
servo.freq(50)  # Standard servo frequency

def map_range(x, in_min, in_max, out_min, out_max):
    return (x - in_min) * (out_max - out_min) // (in_max - in_min) + out_min

def setup():
    print("Initializing...")
    try:
        display.fill(0)
        display.text("Servo Control", 0, 0, 1)
        display.show()
        time.sleep(1)
    except OSError as e:
        print(f"SSD1306 allocation failed: {e}")
        while True:
            pass

def loop():
    pot_value = pot.read()
    angle = map_range(pot_value, 0, 4095, 0, 180)  # Map ADC to 0-180 degrees
    pulse_width = map_range(angle, 0, 180, 500, 2500)  # Map angle to servo pulse width (microseconds)
    servo.duty_ns(pulse_width * 1000) # duty_ns takes nanoseconds.
    display.fill(0)
    display.text("Angle: {} deg".format(angle), 0, 30, 1)
    display.show()
    time.sleep(0.01) #Small delay

# Main execution
setup()
while True:
    loop()
