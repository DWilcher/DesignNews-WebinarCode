const int potPin = A0;

void setup() {
  Serial.begin(9600);
}

void loop() {
  int sensorValue = analogRead(potPin);

  // Send the sensor value to the Serial Plotter
  Serial.println(sensorValue);

  delay(100);  // Adjust the delay as needed
}



