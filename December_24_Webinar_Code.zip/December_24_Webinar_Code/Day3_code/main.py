# Electronic Thermometer - csv format
from machine import Pin, ADC
import time
import math

adc = ADC(Pin(36))
adc.atten(ADC.ATTN_11DB)
adc.width(ADC.WIDTH_12BIT)

try:
    # Print CSV headers
    print("ADC value,Voltage (V),Temperature (°C)")
    while True:
        adcValue = adc.read()
        voltage = adcValue / 4095 * 3.3
        Rt = 10 * voltage / (3.3 - voltage)
        tempK = 1 / (1 / (273.15 + 25) + (math.log(Rt / 10)) / 3950)
        tempC = tempK - 273.15
        # Print values in CSV format
        print(f"{adcValue},{voltage:.2f},{tempC:.2f}")
        time.sleep_ms(1000)
except:
    pass
