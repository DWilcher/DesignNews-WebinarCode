import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Define the rotation matrix and translation vector
R = np.array([[1, 0, 0],
              [0, 0, -1],
              [0, 1, 0]])

translation = np.array([2, -4, 3])

# Set up the figure and 3D axis
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Plot the reference frame (Frame 1 - identity matrix)
ax.quiver(0, 0, 0, 1, 0, 0, color='r', length=1, label='Frame 1 X-axis')
ax.quiver(0, 0, 0, 0, 1, 0, color='g', length=1, label='Frame 1 Y-axis')
ax.quiver(0, 0, 0, 0, 0, 1, color='b', length=1, label='Frame 1 Z-axis')

# Plot the rotated frame (Frame 2)
# We need to add the translation for the rotation to the new position
frame_2_origin = translation
ax.quiver(*frame_2_origin, *R[:, 0], color='r', length=1, label='Frame 2 X-axis')
ax.quiver(*frame_2_origin, *R[:, 1], color='g', length=1, label='Frame 2 Y-axis')
ax.quiver(*frame_2_origin, *R[:, 2], color='b', length=1, label='Frame 2 Z-axis')

# Set labels
ax.set_xlabel('X')
ax.set_ylabel('Y')
ax.set_zlabel('Z')

# Add a grid
ax.grid(True)

# Set equal scaling for the axes
ax.set_box_aspect([1, 1, 1])

# Set limits for the axes
ax.set_xlim([-5, 5])
ax.set_ylim([-5, 5])
ax.set_zlim([-5, 5])

# Title
ax.set_title('Rotation and New Orientation of End Effector (Frame 2)')

# Show legend
ax.legend()

# Show the plot
plt.show()
