#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

//Adafruit_SSD1306 display(128, 64);

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

#define OLED_RESET  4
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

const int potPin = A0; // Define the analog pin connected to the potentiometer

void setup() {
    Serial.begin(9600);
    display.setTextColor(SSD1306_WHITE);// Set the color for the text

  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) { // The I2C address for this particular OLED display is provided.
    Serial.println(F("SSD1306 allocation failed"));
    for(;;);
  }

  
  // Set the background color to black
  display.fillRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, SSD1306_BLACK);
  display.display();
  delay(2000);
  display.clearDisplay();  // Clear the display after setting the background color
}
  

void loop() {
  int potValue = analogRead(potPin); // Read the potentiometer value
  //int potPercentage = map(potValue, 0, 1023, 0, 100); // Convert the potentiometer value to a percentage (0-100)

  // Display the potentiometer value and percentage on the OLED display
  display.clearDisplay();
  display.setTextSize(2);
  display.setCursor(0, 0);
  display.print("Pot Value");
  display.setTextSize(2);
  display.setCursor(64,24);
  display.print(potValue);
  Serial.println(potValue);
  delay(100);
 
 // If the sensor value is greater than 800, turn on the onboard LED
  if (potValue > 800) {
    digitalWrite(LED_BUILTIN, HIGH);
  } else {
    digitalWrite(LED_BUILTIN, LOW);
  }
  

  display.display(); // Update the display
}

