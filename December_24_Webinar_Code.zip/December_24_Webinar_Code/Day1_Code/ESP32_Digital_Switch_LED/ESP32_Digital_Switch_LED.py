from machine import Pin
import time

# Define GPIO pins
button_pin = Pin(18, Pin.IN)  # Pushbutton with pull-up resistor
led_pin = Pin(2, Pin.OUT)  # LED pin

# Main loop
try:
    while True:
        # Read the state of the button
        button_state = button_pin.value()

        if button_state == 1:  # Button pressed (active low)
            led_pin.value(1)  # Turn on LED
        else:  # Button released
            led_pin.value(0)  # Turn off LED

        time.sleep(0.05)  # Debounce delay
except KeyboardInterrupt:
    print("Program stopped")

