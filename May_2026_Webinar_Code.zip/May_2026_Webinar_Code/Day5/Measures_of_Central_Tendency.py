import pandas as pd
import numpy as np
import ipywidgets as widgets
from IPython.display import display, clear_output
import matplotlib.pyplot as plt
import seaborn as sns
import io
from google.colab import files

def run_analysis_tool():
    print("Please upload your CSV file:")

    # 1. Trigger Colab File Upload
    uploaded = files.upload()

    if not uploaded:
        print("No file was uploaded. Please run the cell again.")
        return

    # Extract the filename from the uploaded dictionary
    file_name = next(iter(uploaded))

    # 2. Read the CSV Data
    try:
        df = pd.read_csv(io.BytesIO(uploaded[file_name]))
        print(f"\nSuccessfully loaded: {file_name}")
        print(f"Dataset shape: {df.shape[0]} rows and {df.shape[1]} columns.\n")
    except Exception as e:
        print(f"Error reading the CSV file: {e}")
        return

    # 3. Filter for numeric columns to prevent calculation errors
    numeric_cols = df.select_dtypes(include=np.number).columns.tolist()

    if not numeric_cols:
        print("No numeric columns found in the dataset to calculate central tendencies.")
        return

    # 4. Create the Interactive Dropdown Widget
    col_dropdown = widgets.Dropdown(
        options=numeric_cols,
        description='Select Column:',
        style={'description_width': 'initial'},
        layout={'width': 'max-content'}
    )

    # Output area for rendering the results and plots
    output_area = widgets.Output()

    # 5. Define the core analysis and plotting function
    def analyze_and_plot(column_name):
        with output_area:
            clear_output(wait=True) # Clear previous results

            # Drop NaN values for accurate calculation
            col_data = df[column_name].dropna()

            if col_data.empty:
                print(f"Column '{column_name}' contains no valid numeric data.")
                return

            # --- Calculate Measures of Central Tendency ---
            mean_val = col_data.mean()
            median_val = col_data.median()

            # Mode can return multiple values if there's a tie
            mode_series = col_data.mode()
            if len(mode_series) == len(col_data):
                 mode_val = "No distinct mode (all values are unique)"
                 mode_plot_val = None
            else:
                 mode_val = mode_series.tolist()
                 mode_plot_val = mode_val[0] # Use the first mode for plotting

            # --- Display Text Report ---
            print(f"--- Descriptive Statistics for: {column_name} ---")
            print(f"Count (valid rows): {len(col_data)}")
            print(f"Mean:   {mean_val:.4f}")
            print(f"Median: {median_val:.4f}")
            print(f"Mode:   {mode_val}\n")

            # --- Generate Interactive Visual Report ---
            plt.figure(figsize=(10, 5))

            # Plot the histogram with a Kernel Density Estimate (KDE)
            sns.histplot(col_data, kde=True, bins=30, color='lightsteelblue')

            # Overlay Central Tendency lines
            plt.axvline(mean_val, color='red', linestyle='--', linewidth=2, label=f'Mean: {mean_val:.2f}')
            plt.axvline(median_val, color='green', linestyle='-', linewidth=2, label=f'Median: {median_val:.2f}')

            if mode_plot_val is not None:
                plt.axvline(mode_plot_val, color='purple', linestyle=':', linewidth=2, label=f'Mode (1st): {mode_plot_val:.2f}')

            plt.title(f'Data Distribution & Central Tendency: {column_name}')
            plt.xlabel(column_name)
            plt.ylabel('Frequency')
            plt.legend()

            # Render the plot
            plt.show()

    # 6. Define the event handler for the dropdown changes
    def on_dropdown_change(change):
        if change['type'] == 'change' and change['name'] == 'value':
            analyze_and_plot(change['new'])

    # 7. Attach the event handler to the dropdown
    col_dropdown.observe(on_dropdown_change)

    # 8. Display the UI and run the initial analysis on the first available column
    print("--- Interactive Analysis Tool ---")
    display(col_dropdown, output_area)
    analyze_and_plot(numeric_cols[0])

# Execute the program
run_analysis_tool()