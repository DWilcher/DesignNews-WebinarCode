#include <Arduino.h>

// Counter to keep track of the 4-bit binary sequence (0 to 15 / 0x0 to 0xF)
int counter = 0;

// Non-blocking timer variables for the binary count speed
unsigned long previousMillis = 0;
const long interval = 500; // Time step between numbers (in milliseconds)

// Explicit array mapping according to your layout:
// LED1 (Index 0) -> LED_D0 (MSB, Bit 3)
// LED2 (Index 1) -> LED_D1 (Bit 2)
// LED3 (Index 2) -> LED_D2 (Bit 1)
// LED4 (Index 3) -> LED_D3 (LSB, Bit 0)
int LEDS[] = {LED_D0, LED_D1, LED_D2, LED_D3};
int NUM_LEDS = 4;

void setup() {
  // Initialize Opta user LEDs.
  for(int i = 0; i < NUM_LEDS; i++) {
    pinMode(LEDS[i], OUTPUT);
    digitalWrite(LEDS[i], LOW); // Ensure they start OFF
  }
}

void loop() {
  unsigned long currentMillis = millis();

  // Non-blocking timer to handle the automatic counting sequence
  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;

    // Control the status LEDs based on the current counter value
    changeLights();

    // Increment the counter forward (0 -> 1 -> 2 ... -> 15)
    counter++; 
    
    // Reset back to 0 once we've completed the 0 to 15 (0xF) sequence.
    if (counter > 15) {
      counter = 0;
    }
  }
}

/**
  Control the status LEDs to display the counter in true binary.
  LED4 (LED_D3) acts as LSB (Bit 0)
  LED1 (LED_D0) acts as MSB (Bit 3)
*/
void changeLights() {
  // Extract individual bits from the counter using precise shifting masks
  int bit0 = (counter >> 0) & 1; // LSB
  int bit1 = (counter >> 1) & 1;
  int bit2 = (counter >> 2) & 1;
  int bit3 = (counter >> 3) & 1; // MSB

  // Write the specific bit directly to its designated LED
  digitalWrite(LEDS[3], bit0); // LED4 gets LSB
  digitalWrite(LEDS[2], bit1); // LED3
  digitalWrite(LEDS[1], bit2); // LED2
  digitalWrite(LEDS[0], bit3); // LED1 gets MSB
}
